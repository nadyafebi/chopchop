# Get details from config file
. sensitive/config.sh
IMAGENAME=chop-chop-app

docker build -t ${IMAGENAME} .
docker tag ${IMAGENAME} ${HOSTNAME}/${GCLOUD_PROJECTID}/${IMAGENAME}
docker push ${HOSTNAME}/${GCLOUD_PROJECTID}/${IMAGENAME}